<?php

namespace App\Services;

use App\Enums\OrderStatus;
use App\Enums\PaymentStatus;
use App\Mail\EticketMail;
use App\Models\Order;
use App\Models\Payment;
use App\Models\User;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\ValidationException;
use Throwable;

class PaymentService
{
    public function __construct(private TicketIssuanceService $ticketIssuance, private AuditLogService $auditLogs) {}

    public function selectManualTransfer(Order $order): Payment
    {
        return DB::transaction(function () use ($order): Payment {
            $lockedOrder = Order::query()->whereKey($order->id)->lockForUpdate()->firstOrFail();

            if ($lockedOrder->order_status !== OrderStatus::Pending || $lockedOrder->expires_at?->isPast()) {
                throw ValidationException::withMessages([
                    'order' => 'This order is no longer accepting payment.',
                ]);
            }

            $pendingPayment = $lockedOrder->payments()
                ->where('status', PaymentStatus::Pending)
                ->latest('id')
                ->first();

            if ($pendingPayment) {
                return $pendingPayment;
            }

            $lockedOrder->update([
                'payment_method' => 'bank_transfer',
                'payment_status' => PaymentStatus::Pending,
            ]);

            return $lockedOrder->payments()->create([
                'provider' => 'manual',
                'method' => 'bank_transfer',
                'amount' => $lockedOrder->total_amount,
                'status' => PaymentStatus::Pending,
            ]);
        });
    }

    public function uploadManualProof(Order $order, UploadedFile $proof): Payment
    {
        $path = $proof->store('payment-proofs', 'local');

        try {
            return DB::transaction(function () use ($order, $path): Payment {
                $lockedOrder = Order::query()->whereKey($order->id)->lockForUpdate()->firstOrFail();

                if ($lockedOrder->order_status !== OrderStatus::Pending || $lockedOrder->expires_at?->isPast()) {
                    throw ValidationException::withMessages([
                        'order' => 'This order is no longer accepting payment.',
                    ]);
                }

                $payment = $lockedOrder->payments()
                    ->where('status', PaymentStatus::Pending)
                    ->latest('id')
                    ->lockForUpdate()
                    ->first();

                if (! $payment) {
                    throw ValidationException::withMessages([
                        'payment' => 'Select manual transfer before uploading proof.',
                    ]);
                }

                if ($payment->proof_path || $payment->proof_uploaded_at) {
                    throw ValidationException::withMessages([
                        'proof' => 'Bukti pembayaran sudah diupload dan sedang menunggu verifikasi.',
                    ]);
                }

                $oldPath = $payment->proof_path;
                $payment->update([
                    'proof_path' => $path,
                    'proof_uploaded_at' => now(),
                ]);

                if ($oldPath && $oldPath !== $path) {
                    Storage::disk('local')->delete($oldPath);
                }

                return $payment->fresh();
            });
        } catch (Throwable $exception) {
            Storage::disk('local')->delete($path);

            throw $exception;
        }
    }

    /**
     * @param  array{status: string, provider_transaction_id?: ?string, note?: ?string}  $data
     */
    public function verifyManual(Order $order, array $data, User $user): Payment
    {
        $eticketDelivery = null;
        $payment = DB::transaction(function () use ($order, $data, $user, &$eticketDelivery): Payment {
            $lockedOrder = Order::query()->whereKey($order->id)->lockForUpdate()->firstOrFail();
            $payment = $lockedOrder->payments()->latest('id')->lockForUpdate()->first();

            if (! $payment) {
                throw ValidationException::withMessages([
                    'order_id' => 'No payment exists for this order.',
                ]);
            }

            $targetStatus = PaymentStatus::from($data['status']);

            if ($payment->status !== PaymentStatus::Pending) {
                if ($payment->status === $targetStatus) {
                    return $payment;
                }

                throw ValidationException::withMessages([
                    'status' => 'This payment has already been processed.',
                ]);
            }

            if ($lockedOrder->order_status !== OrderStatus::Pending || $lockedOrder->expires_at?->isPast()) {
                throw ValidationException::withMessages([
                    'order_id' => 'This order is no longer accepting payment.',
                ]);
            }

            $reference = $data['provider_transaction_id'] ?? null;

            if ($reference && Payment::query()
                ->where('provider_transaction_id', $reference)
                ->where($payment->getKeyName(), '!=', $payment->id)
                ->exists()) {
                throw ValidationException::withMessages([
                    'provider_transaction_id' => 'This transaction reference has already been used.',
                ]);
            }

            $oldValues = [
                'payment_status' => $payment->status->value,
                'order_status' => $lockedOrder->order_status->value,
            ];

            $payment->update([
                'status' => $targetStatus,
                'provider_transaction_id' => $reference,
                'paid_at' => $targetStatus === PaymentStatus::Paid ? now() : null,
            ]);

            $lockedOrder->update([
                'payment_status' => $targetStatus,
                'order_status' => $targetStatus === PaymentStatus::Paid
                    ? OrderStatus::Paid
                    : OrderStatus::Pending,
                'paid_at' => $targetStatus === PaymentStatus::Paid ? now() : null,
            ]);

            if ($targetStatus === PaymentStatus::Paid) {
                $issued = $this->ticketIssuance->issue($lockedOrder);
                $lockedOrder->load('event');
                $issued['tickets']->each(fn ($ticket) => $ticket->load('attendee'));

                $delivery = $lockedOrder->emailDeliveries()->create([
                    'recipient' => $lockedOrder->customer_email,
                    'type' => 'eticket',
                    'status' => 'queued',
                    'queued_at' => now(),
                ]);

                $eticketDelivery = [
                    'recipient' => $lockedOrder->customer_email,
                    'order_number' => $lockedOrder->order_number,
                    'event_title' => $lockedOrder->event->title,
                    'tickets' => $issued['tickets'],
                    'delivery_id' => $delivery->id,
                ];
            }

            $this->auditLogs->record(
                'payment.manual_verified',
                $payment,
                $user,
                $oldValues,
                [
                    'payment_status' => $targetStatus->value,
                    'order_status' => $lockedOrder->order_status->value,
                    'note' => $data['note'] ?? null,
                ],
            );

            return $payment->fresh();
        });

        if ($eticketDelivery !== null) {
            Mail::to($eticketDelivery['recipient'])->queue(new EticketMail(
                $eticketDelivery['order_number'],
                $eticketDelivery['event_title'],
                $eticketDelivery['tickets'],
                $eticketDelivery['delivery_id'],
            ));
        }

        return $payment;
    }
}
