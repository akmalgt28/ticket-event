<?php echo e($slot); ?>

<?php /**PATH D:\FP\Ticket Event\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>