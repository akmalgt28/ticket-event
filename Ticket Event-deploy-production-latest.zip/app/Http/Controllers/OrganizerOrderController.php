<?php

namespace App\Http\Controllers;

use App\Enums\OrderStatus;
use App\Enums\PaymentStatus;
use App\Http\Resources\OrderResource;
use App\Mail\EticketMail;
use App\Models\Order;
use App\Models\Payment;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Throwable;
use Illuminate\Validation\ValidationException;
use Inertia\Inertia;
use Inertia\Response as InertiaResponse;
use Symfony\Component\HttpFoundation\StreamedResponse;

class OrganizerOrderController extends Controller
{
    public function index(Request $request): JsonResponse|InertiaResponse
    {
        Gate::authorize('viewAny', Order::class);

        $orders = Order::query()
            ->with('event:id,title')
            ->withCount('tickets')
            ->when(! $request->expectsJson(), fn ($query) => $query->with(['payments' => fn ($query) => $query->latest('id')]))
            ->when($request->filled('status'), function ($query) use ($request): void {
                $status = OrderStatus::tryFrom((string) $request->query('status'));

                if ($status !== null) {
                    $query->where('order_status', $status->value);
                }
            })
            ->when($request->filled('payment_status'), function ($query) use ($request): void {
                $status = PaymentStatus::tryFrom((string) $request->query('payment_status'));

                if ($status !== null) {
                    $query->where('payment_status', $status->value);
                }
            })
            ->when($request->filled('search'), function ($query) use ($request): void {
                $search = trim((string) $request->query('search'));

                $query->where(function ($query) use ($search): void {
                    $query->where('order_number', 'like', "%{$search}%")
                        ->orWhere('customer_name', 'like', "%{$search}%")
                        ->orWhere('customer_email', 'like', "%{$search}%");
                });
            })
            ->latest('id')
            ->paginate(20)
            ->withQueryString();

        if ($request->expectsJson()) {
            return response()->json([
                'data' => OrderResource::collection($orders),
            ]);
        }

        return Inertia::render('Organizer/Orders', [
            'orders' => $orders->through(fn (Order $order): array => [
                'id' => $order->id,
                'order_number' => $order->order_number,
                'customer_name' => $order->customer_name,
                'customer_email' => $order->customer_email,
                'total_amount' => (string) $order->total_amount,
                'order_status' => $order->order_status?->value,
                'payment_status' => $order->payment_status?->value,
                'tickets_count' => $order->tickets_count,
                'event' => $order->event?->title,
                'payment' => $order->payments->first() ? [
                    'status' => $order->payments->first()->status?->value,
                    'amount' => (string) $order->payments->first()->amount,
                    'proof_url' => $order->payments->first()->proof_path
                        ? route('organizer.payments.proof', $order->payments->first()->id)
                        : null,
                ] : null,
            ]),
            'filters' => [
                'search' => (string) $request->query('search', ''),
                'status' => (string) $request->query('status', ''),
                'payment_status' => (string) $request->query('payment_status', ''),
            ],
        ]);
    }

    public function downloadProof(Payment $payment): StreamedResponse
    {
        Gate::authorize('view', $payment->order);

        abort_unless($payment->proof_path, 404);

        return Storage::disk('local')->download(
            $payment->proof_path,
            'payment-proof-'.$payment->id.'.'.pathinfo($payment->proof_path, PATHINFO_EXTENSION),
        );
    }

    public function show(Order $order): JsonResponse
    {
        Gate::authorize('view', $order);

        return (new OrderResource($order->load([
            'event:id,title,slug,start_at,end_at,location_name,location_address',
            'items.ticketType:id,name',
            'attendees',
            'payments',
            'tickets',
        ])))->response();
    }

    public function resendEticket(Order $order): RedirectResponse
    {
        Gate::authorize('view', $order);

        if ($order->order_status !== OrderStatus::Paid) {
            throw ValidationException::withMessages([
                'order' => 'E-ticket hanya dapat dikirim untuk order paid.',
            ]);
        }

        $order->load(['event', 'tickets.attendee', 'tickets.orderItem']);

        if ($order->tickets->isEmpty()) {
            throw ValidationException::withMessages([
                'order' => 'Order belum memiliki ticket.',
            ]);
        }

        foreach ($order->tickets as $ticket) {
            if (! $ticket->qr_token) {
                $token = Str::random(64);
                $ticket->update([
                    'qr_token_hash' => hash('sha256', $token),
                    'qr_token' => $token,
                ]);
            }
        }

        $delivery = $order->emailDeliveries()->create([
            'recipient' => $order->customer_email,
            'type' => 'eticket',
            'status' => 'queued',
            'queued_at' => now(),
        ]);

        $mail = new EticketMail(
            $order->order_number,
            $order->event->title,
            $order->customer_name,
            $order->customer_email,
            $order->customer_phone,
            $order->tickets,
            $delivery->id,
            [
                'date' => $order->event->start_at?->format('d M Y') ?? '-',
                'time' => $order->event->start_at && $order->event->end_at
                    ? $order->event->start_at->format('H:i').' - '.$order->event->end_at->format('H:i').' WIB'
                    : ($order->event->start_at?->format('H:i').' WIB' ?? '-'),
                'location_name' => $order->event->location_name ?? '-',
                'location_address' => $order->event->location_address,
                'organizer_name' => $order->event->organizer_name ?? 'Penyelenggara Event',
            ],
        );

        try {
            Mail::mailer('resend')->to($order->customer_email)->sendNow($mail);
        } catch (Throwable $exception) {
            $mail->failed($exception);
            report($exception);

            return back()->withErrors([
                'order' => 'E-ticket gagal dikirim. Coba lagi setelah memastikan layanan email tersedia.',
            ]);
        }

        return back()->with('success', "E-ticket order {$order->order_number} berhasil dikirim.");
    }
}
