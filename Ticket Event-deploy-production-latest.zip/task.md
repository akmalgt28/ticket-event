# Task Plan - Platform Pemesanan Seminar & Workshop

Dokumen ini adalah checklist setup proyek berdasarkan `prd.md`. Fokus tahap awal hanya menyiapkan environment dan project foundation.

## Aturan Utama

- Jangan mulai coding fitur sebelum Laravel berhasil diinstall.
- Jangan membuat migration, model, controller, route bisnis, atau UI fitur sebelum checkpoint Laravel selesai.
- Jangan install payment gateway sebelum provider dan metode pembayaran diputuskan.
- Jangan menambahkan package yang belum punya kebutuhan jelas.
- Setiap task ditandai selesai hanya setelah command verifikasi berhasil.

## 0. Keputusan Setup

- [x] Nama project: `ticket-event`
- [x] Backend: Laravel
- [x] Database: SQLite (sementara untuk lokal dan production)

Catatan keputusan: SQLite dipakai sementara untuk lokal dan production; migrasi PostgreSQL ditunda.
- [x] Frontend: Inertia.js + Vue + Tailwind CSS + Vite
- [x] Authentication internal: Laravel Fortify atau starter kit Laravel yang kompatibel
- [x] Authorization: Spatie Laravel Permission
- [x] API token jika dibutuhkan: Laravel Sanctum
- [ ] Email transactional: Resend sebagai kandidat awal
- [ ] Deployment: VPS dengan aaPanel
- [x] Peserta: guest checkout, tanpa login
- [ ] Target awal: satu organizer dan satu event

## 1. Cek Environment Lokal

### Required Tools

- [x] PHP terpasang dengan extension minimum Laravel dan PostgreSQL.
- [x] Composer terpasang.
- [x] Node.js LTS dan npm terpasang.
- [x] PostgreSQL server dan client terpasang.
- [x] Git terpasang.
- [ ] Editor kode terpasang.

### Verification Commands

Jalankan dari PowerShell:

```powershell
php -v
php -m
composer --version
node --version
npm --version
psql --version
git --version
```

### PHP Extensions

Pastikan extension yang dibutuhkan tersedia:

- [x] `bcmath`
- [x] `ctype`
- [x] `curl`
- [x] `fileinfo`
- [x] `mbstring`
- [x] `openssl`
- [x] `pdo`
- [x] `pdo_pgsql`
- [x] `tokenizer`
- [x] `xml`
- [x] `zip`

Jika extension belum tersedia, aktifkan melalui `php.ini`, lalu ulangi `php -m`.

## 2. Install Laravel

### Project Creation

- [x] Pastikan folder project belum berisi source code Laravel.
- [x] Install Laravel menggunakan Composer.

Contoh command:

```powershell
composer create-project laravel/laravel ticket-event
cd ticket-event
```

Jika project memang harus dibuat langsung di folder saat ini, pastikan folder hanya berisi file dokumentasi yang aman untuk dipertahankan, lalu gunakan command yang sesuai dengan kondisi folder.

### Laravel Checkpoint - WAJIB SELESAI SEBELUM CODING

- [x] `php artisan --version` berhasil.
- [x] File `.env` tersedia.
- [x] `php artisan key:generate` berhasil.
- [x] `php artisan about` berhasil.
- [x] `php artisan serve` dapat menjalankan aplikasi.
- [x] Halaman default Laravel dapat dibuka melalui browser.
- [ ] Tidak ada deprecation warning dari Composer pada PHP 8.5.

Catatan: PostgreSQL 17 terpasang dan service aktif. Binary `psql` tersedia di `C:\Program Files\PostgreSQL\17\bin\psql.exe`, tetapi belum masuk PATH. Koneksi membutuhkan password user PostgreSQL.

Verification commands:

```powershell
php artisan --version
php artisan key:generate
php artisan about
php artisan serve
```

**Gate:** Jika checkpoint ini belum selesai, berhenti. Jangan membuat fitur aplikasi.

## 3. Inisialisasi Repository dan Environment

- [x] Inisialisasi Git jika folder belum menjadi repository.
- [x] Pastikan `.env` tidak masuk Git.
- [x] Pastikan `.env.example` tidak berisi secret.
- [ ] Buat database PostgreSQL lokal.
- [x] Isi konfigurasi database di `.env`.
- [x] Jalankan koneksi database melalui command Laravel.
- [x] Catat versi PHP, Laravel, SQLite, Node.js, dan npm.

Contoh konfigurasi `.env`:

```dotenv
DB_CONNECTION=pgsql
DB_HOST=127.0.0.1
DB_PORT=5432
DB_DATABASE=ticket_event
DB_USERNAME=postgres
DB_PASSWORD=
```

Verification:

```powershell
php artisan config:clear
php artisan migrate:status
```

## 4. Setup Frontend Foundation

- [x] Pastikan Inertia.js dan Vue menggunakan versi yang kompatibel dengan versi Laravel.
- [x] Install adapter server Inertia.
- [x] Install adapter Vue Inertia.
- [x] Install Vue dan dependency frontend yang diperlukan.
- [x] Pastikan Tailwind CSS dan Vite sudah aktif.
- [x] Jalankan build frontend.

Verification:

```powershell
npm install
npm run build
```

Jangan menambahkan komponen halaman event pada tahap ini. Hanya verifikasi asset pipeline.

## 5. Setup Authentication Internal

Scope authentication hanya untuk organizer, admin, dan staff. Peserta tetap guest checkout.

- [x] Pilih starter authentication yang kompatibel dengan versi Laravel.
- [x] Install starter kit Breeze Inertia + Vue yang kompatibel dengan Laravel 13.
- [x] Pilih Inertia + Vue tanpa mengaktifkan login peserta sebagai syarat pembelian.
- [x] Aktifkan login internal.
- [x] Aktifkan password reset.
- [x] Aktifkan email verification untuk akun internal bila diperlukan.
- [x] Verifikasi logout dan proteksi route internal.

Catatan: `laravel/fortify` tidak dipasang karena tidak kompatibel dengan Laravel 13. Breeze dipakai untuk auth internal. Sanctum tersedia untuk API token atau integrasi eksternal, sedangkan Inertia memakai session authentication sebagai mekanisme utama.

## 6. Install Package Backend

Install setelah Laravel checkpoint selesai.

### Package Wajib atau Kandidat Utama

- [x] Starter kit auth yang kompatibel: `laravel/breeze`.
- [x] `spatie/laravel-permission` untuk role dan permission.
- [x] `laravel/sanctum` jika API token diperlukan.
- [x] Package QR code PHP yang kompatibel dengan versi PHP dan Laravel.
- [x] `resend/resend-php` atau integration resmi Resend yang kompatibel.

Catatan: `laravel/fortify` tidak dipasang karena tidak kompatibel dengan Laravel 13. Authentication internal menggunakan Breeze Inertia + Vue.

### Package yang Ditunda

- [x] Payment gateway: tunggu keputusan provider.
- [x] WhatsApp/SMS provider: bukan bagian MVP awal.
- [x] Storage cloud: gunakan local storage terlebih dahulu jika cukup.
- [x] CSV package: gunakan export native Laravel/PHP jika kebutuhan masih sederhana.

### Verification Package

- [x] Jalankan `composer install` tanpa error.
- [x] Jalankan `php artisan package:discover` tanpa error.
- [x] Jalankan `php artisan optimize:clear` tanpa error.
- [x] Pastikan package terdaftar di `composer.json` dan `composer.lock`.
- [x] Pastikan tidak ada dependency yang membutuhkan versi PHP di luar environment.

## 7. Setup Email Resend

Resend masih berstatus kandidat provider, tetapi struktur aplikasi perlu disiapkan agar provider dapat diganti.

- [ ] Buat akun dan domain pengirim di Resend jika provider dipilih.
- [ ] Verifikasi domain pengirim dan konfigurasi DNS.
- [ ] Simpan API key hanya di `.env` lokal/server.
- [ ] Tambahkan konfigurasi mail Laravel untuk Resend.
- [x] Buat queue untuk pengiriman email.
- [x] Konfigurasi retry dan failed jobs.
- [ ] Uji email sederhana ke alamat internal.
- [x] Uji pencatatan `message_id` dan status pengiriman jika tersedia.

Contoh variable environment yang perlu disiapkan kemudian:

```dotenv
MAIL_MAILER=resend
RESEND_KEY=
MAIL_FROM_ADDRESS=
MAIL_FROM_NAME="Ticket Event"
QUEUE_CONNECTION=database
```

Jangan commit API key atau credential email.

## 8. Setup Queue dan Scheduler

- [x] Pilih queue driver awal: database atau Redis.
- [x] Untuk MVP lokal, database queue cukup jika Redis belum dibutuhkan.
- [x] Aktifkan failed jobs.
- [x] Siapkan worker lokal.
- [x] Siapkan scheduler untuk order expired; retry email ditangani queue.
- [ ] Dokumentasikan konfigurasi Supervisor untuk VPS aaPanel.

Verification:

```powershell
php artisan queue:failed
php artisan schedule:list
```

## 9. Setup Quality and Security Baseline

- [x] Pastikan `.env` masuk `.gitignore`.
- [x] Jalankan `composer validate`.
- [x] Jalankan `composer audit`.
- [x] Jalankan `npm audit` dan review hasilnya.
- [x] Pastikan APP_KEY tidak kosong.
- [ ] Pastikan `APP_DEBUG=false` hanya pada environment production.
- [ ] Pastikan HTTPS direncanakan untuk production.
- [x] Pastikan upload file akan dibatasi berdasarkan ukuran, MIME type, dan ekstensi.
- [ ] Pastikan webhook payment nanti diverifikasi dengan signature.
- [ ] Pastikan backup SQLite direncanakan sebelum deployment.

## 10. Setup Testing Baseline

- [x] Pastikan test runner bawaan Laravel dapat berjalan.
- [x] Jalankan test bawaan tanpa mengubah behavior aplikasi.
- [x] Pastikan test environment tidak menggunakan database production.
- [x] Siapkan database test PostgreSQL atau SQLite sesuai kompatibilitas fitur.
- [x] Tetapkan bahwa alur penting wajib memiliki test: guest checkout, kuota tiket, pembayaran, email ticket, dan check-in atomic.

Verification:

```powershell
php artisan test
```

## 11. Deployment Preparation - aaPanel VPS

Dilakukan setelah project lokal stabil.

- [ ] Siapkan VPS dengan OS LTS.
- [ ] Install aaPanel.
- [ ] Install PHP versi kompatibel dengan project.
- [ ] Install PostgreSQL.
- [ ] Install Nginx.
- [ ] Install Node.js hanya jika build dilakukan di server; jika tidak, deploy asset hasil build.
- [ ] Konfigurasi domain dan SSL.
- [ ] Konfigurasi document root ke folder `public` Laravel.
- [ ] Konfigurasi environment production.
- [ ] Konfigurasi queue worker melalui Supervisor.
- [ ] Konfigurasi scheduler Laravel.
- [ ] Konfigurasi database backup off-server.
- [ ] Uji deploy dari repository bersih.
- [ ] Uji restore backup.

## 12. Definition of Ready Sebelum Coding Fitur

Semua checklist berikut harus selesai:

- [x] Laravel terinstall.
- [x] `php artisan --version` berhasil.
- [x] Aplikasi default Laravel dapat dibuka.
- [ ] PostgreSQL terkoneksi.
- [x] `php artisan migrate:status` berhasil.
- [x] Frontend build berhasil.
- [x] Authentication internal berhasil diverifikasi.
- [x] Role dan permission package terpasang.
- [x] Email provider sudah dipilih atau adapter email sudah diabstraksikan dengan jelas.
- [x] `composer audit` dan `npm audit` sudah ditinjau.
- [x] `php artisan test` berhasil.
- [x] Versi dependency dicatat.

Setelah Definition of Ready selesai, mulai Level 1. Jangan melewati level tanpa memenuhi Definition of Done level sebelumnya.

## 13. Urutan Level Pengerjaan

Urutan wajib:

```text
Level 0  Environment dan Laravel
Level 1  Database dan domain model
Level 2  Backend foundation dan authorization
Level 3  API/domain endpoints dan business rules
Level 4  Frontend public event dan checkout
Level 5  Dashboard organizer dan staff check-in
Level 6  Email, payment, e-ticket, dan queue
Level 7  Testing, security, dan hardening
Level 8  Deployment VPS aaPanel
Level 9  UAT dan release MVP
```

Jika implementasi memakai Inertia, Level 3 tidak berarti harus membuat REST API publik terpisah. Buat controller, request, resource/transformer, dan endpoint internal yang diperlukan Inertia terlebih dahulu. REST API publik hanya dibuat jika ada client eksternal.

## Level 0 - Environment dan Laravel

### Tujuan

Menyiapkan project Laravel yang dapat dijalankan secara lokal.

### Tasks

- [ ] Selesaikan semua checklist pada bagian 1 sampai 12.
- [x] Install Laravel di lokasi project yang disepakati.
- [x] Verifikasi `php artisan --version`.
- [ ] Verifikasi halaman default Laravel melalui browser.
- [x] Konfigurasi `.env` lokal.
- [ ] Hubungkan Laravel ke PostgreSQL.
- [ ] Catat versi dependency dan tool.

### Definition of Done

- [x] Laravel berjalan tanpa error.
- [ ] PostgreSQL dapat diakses dari Laravel.
- [x] `php artisan migrate:status` berhasil.
- [x] `npm run build` berhasil.
- [ ] Tidak ada fitur bisnis yang dibuat pada level ini.

## Level 1 - Database dan Domain Model

### Tujuan

Membuat struktur data yang menjadi sumber kebenaran untuk event, tiket, order, pembayaran, peserta, dan check-in.

### 1.1 Database Schema

- [x] Buat migration `events`.
- [x] Buat migration `ticket_types`.
- [x] Buat migration `orders`.
- [x] Buat migration `order_items`.
- [x] Buat migration `attendees`.
- [x] Buat migration `tickets`.
- [x] Buat migration `payments`.
- [x] Buat migration `audit_logs`.
- [x] Tambahkan foreign key dan index yang diperlukan.
- [x] Tambahkan unique index untuk `events.slug`, `orders.order_number`, dan `tickets.ticket_number`.
- [x] Tambahkan unique constraint untuk token tiket yang sudah di-hash.
- [x] Gunakan tipe data uang yang aman untuk PostgreSQL; jangan gunakan floating point.
- [x] Gunakan `jsonb` hanya untuk metadata yang memang fleksibel.
- [x] Tentukan strategi soft delete hanya untuk data yang memang perlu dipulihkan. Keputusan: data transaksi dan ticket tidak memakai soft delete agar histori tetap utuh.

### 1.2 Enum dan Status

- [x] Definisikan status event: `draft`, `published`, `closed`, `cancelled`.
- [x] Definisikan status ticket type: `active`, `inactive`.
- [x] Definisikan status order: `pending`, `paid`, `expired`, `cancelled`, `refunded`.
- [x] Definisikan status payment: `pending`, `paid`, `failed`, `expired`, `refunded`.
- [x] Definisikan status ticket: `issued`, `used`, `cancelled`.
- [x] Gunakan PHP backed enum atau mekanisme konsisten lain.
- [x] Validasi transisi status di satu tempat.

### 1.3 Model dan Relationship

- [x] Buat model Eloquent untuk semua tabel domain.
- [x] Definisikan relationship antar model.
- [x] Tambahkan casts untuk uang, tanggal, dan metadata.
- [x] Tambahkan factory untuk data test.
- [x] Tambahkan seeder role owner untuk local environment.
- [x] Jangan menaruh aturan bisnis inti di view atau migration.

### 1.4 Data Integrity

- [x] Tambahkan constraint kuota tidak negatif.
- [x] Tambahkan constraint harga tidak negatif.
- [x] Pastikan email order wajib terisi.
- [x] Pastikan satu ticket hanya punya satu check-in berhasil.
- [x] Tentukan apakah `sold_count` disimpan atau dihitung; jangan gunakan dua sumber tanpa sinkronisasi.
- [x] Gunakan transaction untuk pembuatan order dan perubahan kuota.

### Verification

```powershell
php artisan migrate:fresh --seed
php artisan db:show
php artisan tinker
```

### Definition of Done

- [x] Migration berjalan dari database kosong.
- [x] Seeder menghasilkan data user owner dan role dasar.
- [x] Semua relationship utama dapat diuji melalui test.
- [x] Tidak ada data model penting yang hanya tersimpan di JSON tanpa alasan. JSON hanya dipakai untuk raw provider response, audit snapshot, dan metadata fleksibel.

Catatan: verifikasi sementara memakai SQLite lokal karena credential PostgreSQL belum dikonfigurasi. Schema ditulis kompatibel dengan PostgreSQL dan wajib diverifikasi ulang setelah koneksi PostgreSQL tersedia.

## Level 2 - Backend Foundation dan Authorization

### Tujuan

Menyiapkan authentication internal, role, permission, validasi, policy, dan struktur service backend.

### 2.1 Authentication

- [x] Selesaikan login organizer dan staff.
- [x] Selesaikan logout.
- [x] Selesaikan password reset.
- [x] Selesaikan email verification untuk user internal jika dipakai.
- [x] Pastikan peserta tidak membutuhkan login.
- [x] Pastikan route internal memakai session authentication.

### 2.2 Role dan Permission

- [x] Buat role `owner`.
- [x] Buat role `admin`.
- [x] Buat role `staff`.
- [x] Buat permission event management.
- [x] Buat permission ticket management.
- [x] Buat permission order management.
- [x] Buat permission payment verification.
- [x] Buat permission check-in.
- [x] Buat permission reporting.
- [x] Buat policy untuk event, order, payment, ticket, dan report.
- [x] Uji akses setiap role terhadap route internal.

### 2.3 Request Validation

- [x] Buat Form Request untuk event.
- [x] Buat Form Request untuk ticket type.
- [x] Buat Form Request untuk checkout.
- [x] Buat Form Request untuk payment verification.
- [x] Buat Form Request untuk check-in.
- [x] Validasi upload banner.
- [x] Validasi email, nomor telepon, harga, kuota, tanggal, dan waktu.
- [x] Jangan mempercayai nilai total dari browser.

### 2.4 Backend Structure

- [x] Pisahkan controller tipis dari business logic.
- [x] Buat service untuk kalkulasi order.
- [x] Buat service untuk reservasi kuota.
- [x] Buat service untuk penerbitan tiket.
- [x] Buat service untuk perubahan status order.
- [x] Buat service untuk check-in.
- [x] Buat action atau service untuk audit log. Implementasi: `AuditLogService`.
- [x] Hindari membuat abstraction jika hanya ada satu implementasi dan belum diperlukan. Tidak menambah abstraction payment provider sebelum provider dipilih.

### Definition of Done

- [x] Organizer/staff dapat login.
- [x] Permission menolak akses yang tidak sesuai.
- [x] Semua input domain utama divalidasi melalui Form Request.
- [x] Business logic utama tidak berada di Blade/Vue.
- [x] Unauthorized access menghasilkan response yang benar.

## Level 3 - API/Domain Endpoints dan Business Rules

### Tujuan

Menyediakan endpoint backend yang dipakai halaman Inertia dan integrasi internal, dengan aturan bisnis yang aman.

### 3.1 Public Event Endpoints

- [x] Endpoint daftar event published.
- [x] Endpoint detail event berdasarkan slug.
- [x] Filter event berdasarkan status publish.
- [x] Tampilkan hanya ticket type aktif dan masih dalam periode penjualan.
- [x] Jangan tampilkan data internal organizer.

### 3.2 Organizer Endpoints

- [x] CRUD event.
- [x] Publish event.
- [x] Close event.
- [x] CRUD ticket type.
- [x] Daftar order.
- [x] Detail order.
- [x] Verifikasi pembayaran manual.
- [x] Daftar peserta.
- [x] Export peserta.

### 3.3 Guest Checkout Endpoint

- [x] Endpoint membuat order guest.
- [x] Terima data customer dan attendee.
- [x] Hitung subtotal dan total di server.
- [x] Reservasi kuota dalam database transaction.
- [x] Buat order number yang unik.
- [x] Set `expires_at`.
- [x] Tolak event yang belum published atau sudah closed.
- [x] Tolak tiket yang belum aktif, belum masuk periode jual, atau kuota tidak cukup.
- [x] Jangan membuat ticket sebelum order paid.

### 3.4 Payment Endpoint

- [x] Endpoint memilih metode transfer manual.
- [x] Endpoint upload bukti pembayaran jika fitur tersebut dipakai.
- [x] Endpoint admin memverifikasi pembayaran manual.
- [ ] Endpoint webhook payment gateway disiapkan setelah provider dipilih.
- [ ] Verifikasi signature webhook.
- [x] Terapkan idempotency berdasarkan transaction reference. Reference payment memiliki unique constraint dan diverifikasi service.
- [x] Simpan payment record dan audit log.

### 3.5 Ticket dan Check-in Endpoint

- [x] Generate ticket setelah payment paid.
- [x] Generate token QR acak.
- [x] Simpan hash token QR.
- [x] Endpoint validasi ticket untuk staff.
- [x] Gunakan transaction dan row lock saat check-in.
- [x] Tolak ticket tidak ditemukan, cancelled, atau sudah used.
- [x] Catat user staff dan waktu check-in.

### 3.6 API Resources

- [x] Buat Resource untuk event publik.
- [x] Buat Resource untuk ticket type publik.
- [x] Buat Resource untuk order internal.
- [x] Buat Resource untuk ticket internal.
- [x] Jangan expose password, secret token mentah, atau raw payment response ke frontend.
- [x] Dokumentasikan endpoint yang benar-benar dipakai di `docs/api.md`.

### Definition of Done

- [x] Endpoint public hanya menampilkan event published.
- [x] Guest dapat membuat order tanpa login.
- [x] Kuota tidak oversell pada request bersamaan. Reservasi memakai transaksi dan row lock; covered by checkout tests.
- [x] Total order selalu dihitung server.
- [x] Status order dan payment konsisten.
- [x] Check-in atomic dan tidak bisa dipakai dua kali.

## Level 4 - Frontend Public Event dan Checkout

### Tujuan

Membangun pengalaman peserta dari melihat event sampai menyelesaikan order tanpa login.

### 4.1 Public Pages

- [x] Halaman daftar event.
- [x] Halaman detail event.
- [x] Tampilkan judul, banner, deskripsi, jadwal, lokasi, kontak, dan tiket.
- [x] Tampilkan kuota atau status sold out sesuai keputusan produk.
- [x] Sediakan CTA pemesanan yang jelas.
- [x] Buat layout mobile-first.

### 4.2 Checkout Pages

- [x] Halaman pilihan ticket type dan quantity.
- [x] Halaman data customer.
- [x] Halaman data attendee.
- [x] Halaman ringkasan order.
- [x] Halaman pilihan metode pembayaran.
- [x] Halaman order pending.
- [x] Halaman payment success.
- [x] Halaman payment failed atau expired.
- [x] Jangan meminta login peserta.

### 4.3 UX dan Validation

- [x] Tampilkan error validasi per field.
- [x] Tampilkan batas waktu pembayaran.
- [x] Tampilkan total dari response server.
- [x] Cegah double submit checkout.
- [x] Tampilkan status proses saat request berjalan.
- [x] Pastikan keyboard navigation dan label form tersedia.
- [x] Pastikan layout dapat dipakai pada mobile.

### Definition of Done

- [x] Peserta dapat membeli tiket tanpa akun.
- [x] Refresh halaman tidak menggandakan order.
- [x] Error server ditampilkan dengan aman.
- [x] Tidak ada secret atau data internal di browser.
- [x] Build production berhasil.

## Level 5 - Dashboard Organizer dan Staff Check-in

### Tujuan

Memberikan alat operasional untuk mengelola event, order, peserta, pembayaran, dan check-in.

### 5.1 Organizer Dashboard

- [x] Ringkasan jumlah order.
- [x] Ringkasan tiket terjual dan tersisa.
- [x] Ringkasan pendapatan berdasarkan payment paid.
- [x] Daftar event.
- [x] Form create/edit event.
- [x] Form create/edit ticket type.
- [x] Tombol publish dan close dengan confirmation.

### 5.2 Order dan Participant Management

- [x] Tabel order dengan pagination.
- [x] Filter status order dan payment.
- [x] Search nomor order, nama, dan email.
- [x] Detail customer, attendee, payment, dan ticket.
- [x] Tombol verifikasi pembayaran manual.
- [x] Tombol kirim ulang e-ticket.
- [x] Export CSV peserta.

### 5.3 Staff Check-in

- [x] Halaman check-in khusus staff.
- [x] Input token atau scanner QR dari kamera browser jika kompatibel.
- [x] Tampilkan hasil valid atau alasan penolakan.
- [x] Tampilkan nama peserta dan event setelah validasi berhasil.
- [x] Simpan riwayat check-in.
- [x] Sediakan pencarian manual sebagai fallback scanner.

### Definition of Done

- [x] Organizer dapat mengelola event tanpa database manual.
- [x] Staff hanya dapat mengakses fungsi yang diizinkan.
- [x] Data order dapat dicari dan difilter.
- [x] Check-in berhasil melalui scanner atau input manual.
- [x] Export peserta dapat dibuka dengan spreadsheet.

## Level 6 - Email, Payment, E-ticket, dan Queue

### Tujuan

Menghubungkan proses order paid dengan penerbitan tiket dan komunikasi peserta.

### 6.1 E-ticket

- [x] Buat template e-ticket.
- [x] Sertakan nomor order.
- [x] Sertakan detail event.
- [x] Sertakan identitas peserta.
- [x] Sertakan QR code.
- [x] Sediakan versi HTML email.
- [ ] Sediakan attachment PDF hanya jika benar-benar diperlukan.
- [x] Pastikan token QR tidak berisi data sensitif langsung.

### 6.2 Resend

- [ ] Putuskan Resend sebagai provider final atau dokumentasikan provider pengganti.
- [ ] Konfigurasi sender domain.
- [ ] Konfigurasi API key di environment.
- [x] Kirim email melalui queue.
- [x] Simpan status delivery.
- [x] Tangani retry dan failed jobs.
- [x] Sediakan resend e-ticket dari dashboard.

### 6.3 Transfer Manual

- [x] Tampilkan instruksi pembayaran.
- [x] Simpan reference dan bukti pembayaran jika dipakai.
- [x] Sediakan action verifikasi oleh organizer/admin.
- [x] Setelah verified, jalankan penerbitan ticket satu kali.

### 6.4 Payment Gateway

- [ ] Putuskan provider payment gateway.
- [ ] Daftarkan credential sandbox.
- [ ] Implementasikan create payment.
- [ ] Implementasikan webhook.
- [ ] Verifikasi signature.
- [ ] Tangani expired, failed, paid, dan refund.
- [ ] Uji callback duplicate dan callback out of order.

### Definition of Done

- [x] Order paid menghasilkan ticket tepat satu kali.
- [x] E-ticket terkirim ke email customer.
- [x] Email gagal tercatat dan dapat di-retry.
- [x] Payment manual dan gateway tidak mengubah order secara tidak sah.
- [x] Tidak ada API key di source code atau repository.

## Level 7 - Testing, Security, dan Hardening

### Tujuan

Memastikan alur MVP aman, konsisten, dan dapat dirilis.

### 7.1 Automated Tests

- [x] Test event publish dan close.
- [x] Test ticket quota.
- [x] Test guest checkout.
- [x] Test total order dihitung server.
- [x] Test order expired.
- [x] Test payment manual verification.
- [ ] Test webhook idempotency.
- [x] Test e-ticket generation.
- [x] Test email queued.
- [x] Test QR check-in valid.
- [x] Test QR check-in duplicate ditolak.
- [x] Test role dan permission.
- [x] Test upload banner.

### 7.2 Concurrency Tests

- [ ] Uji dua checkout untuk kuota terakhir.
- [ ] Uji dua check-in untuk ticket yang sama.
- [ ] Pastikan hanya satu request berhasil.
- [x] Pastikan transaction rollback tidak meninggalkan order atau kuota rusak.

### 7.3 Security Review

- [x] Review authorization setiap route internal.
- [x] Review mass assignment pada semua model.
- [x] Review validation upload.
- [x] Review CSRF dan session settings.
- [x] Review rate limiting login, checkout, webhook, dan check-in.
- [x] Review QR token exposure.
- [ ] Review webhook signature.
- [x] Review sensitive logging.
- [x] Jalankan `composer audit`.
- [x] Jalankan `npm audit`.
- [x] Pastikan dependency production tidak membawa package development yang tidak perlu.

### 7.4 Performance Review

- [x] Tambahkan pagination pada tabel besar.
- [x] Tambahkan index untuk slug, order number, email, status, dan timestamp yang sering difilter.
- [x] Hindari N+1 query.
- [x] Jalankan email dan pekerjaan berat melalui queue.
- [x] Review query dashboard.

### Definition of Done

- [x] Test suite lulus.
- [ ] Tidak ada critical atau high security issue yang belum ditangani.
- [ ] Concurrent checkout dan check-in aman.
- [x] Error production tidak membocorkan stack trace atau secret.
- [x] Backup dan restore database SQLite sudah diuji.

## Level 8 - Deployment VPS aaPanel

### Tujuan

Menjalankan aplikasi pada VPS dengan konfigurasi production yang aman.

### Tasks

- [ ] Provision VPS dengan OS LTS.
- [ ] Install dan konfigurasi aaPanel.
- [ ] Install PHP, Composer, Nginx, dan Node.js sesuai kebutuhan; SQLite memakai file database aplikasi.
- [ ] Buat user deployment non-root.
- [ ] Konfigurasi firewall.
- [ ] Konfigurasi domain dan DNS.
- [ ] Aktifkan SSL.
- [ ] Clone repository.
- [ ] Jalankan `composer install --no-dev --optimize-autoloader`.
- [ ] Build asset production.
- [ ] Konfigurasi `.env` production.
- [ ] Jalankan migration dengan prosedur aman.
- [ ] Set document root ke `public`.
- [ ] Jalankan `php artisan storage:link`.
- [ ] Konfigurasi cache config, route, dan view.
- [ ] Konfigurasi Supervisor untuk queue worker.
- [ ] Konfigurasi scheduler.
- [ ] Konfigurasi log rotation.
- [ ] Konfigurasi backup SQLite off-server.
- [ ] Uji rollback deployment.

### Production Verification

- [ ] Homepage dapat dibuka melalui HTTPS.
- [ ] Login organizer berhasil.
- [ ] Guest checkout berhasil di sandbox/test mode.
- [ ] Email Resend berhasil terkirim.
- [ ] Queue worker berjalan.
- [ ] Scheduler berjalan.
- [ ] Check-in berjalan.
- [ ] Backup dapat direstore.

## Level 9 - UAT dan Release MVP

### Tujuan

Memvalidasi sistem dengan skenario nyata sebelum dipakai pada satu event.

### UAT Scenarios

- [x] Organizer membuat event.
- [x] Organizer membuat tipe tiket.
- [x] Organizer mempublikasikan event.
- [x] Peserta melihat event tanpa login.
- [x] Peserta checkout tanpa login.
- [x] Peserta menerima order pending.
- [x] Organizer memverifikasi pembayaran transfer.
- [x] Peserta menerima e-ticket melalui email.
- [x] Staff scan tiket valid.
- [x] Staff mencoba scan tiket yang sama dua kali.
- [x] Organizer melihat rekap penjualan.
- [x] Organizer export data peserta.
- [x] Organizer mengirim ulang e-ticket.
- [x] Order expired tidak dapat digunakan untuk check-in.

### Release Checklist

- [ ] Semua Definition of Done level 0 sampai 8 selesai.
- [ ] Data event production sudah diverifikasi organizer.
- [ ] Sender email dan domain sudah benar.
- [ ] Payment mode production atau transfer manual sudah dipastikan.
- [ ] Backup terakhir berhasil.
- [ ] Kontak support organizer tersedia.
- [ ] Monitoring dan log dapat diakses.
- [ ] Prosedur incident dan rollback tersedia.

## 14. Task Tracking Rules

- Kerjakan satu level dalam satu waktu.
- Pecah task besar menjadi checklist kecil sebelum eksekusi.
- Setelah setiap level selesai, jalankan verification command terkait.
- Jangan menandai selesai berdasarkan asumsi; gunakan output command atau test.
- Jika requirement belum diputuskan, tandai `TBD` dan jangan mengunci implementasi.
- Update PRD jika keputusan produk berubah.
- Update task ini jika urutan atau scope berubah.



































- [x] Pass UI profesional publik: detail event dan cek status order tanpa shadow/glow, radius kecil, brand configurable.
- [x] Pass UI dashboard organizer: hilangkan dekorasi glow dan hover shadow.
- [x] Pass UI lanjutan halaman checkout dan tabel organizer.


- [x] Sticky footer publik dan layout flex utama admin/auth.
- [x] Cleanup auth, profile, component, dan staff UI dari shadow lama.

- [x] Samakan checkbox dengan brand dan hilangkan shadow komponen tersisa.

- [x] Jadikan katalog event sebagai entry point / dan tambah regression test redirect.

- [x] Samakan branding halaman login/register dengan Ticket Event, hapus logo Laravel bawaan dari layout aktif.

- [x] Samakan nav, tombol, label, dan dropdown admin dengan token brand configurable.


## Backend Audit - 2026-10-21

- Selesai: soft-delete strategy, JSON data rationale, AuditLogService, manual payment idempotency, active endpoint documentation, dan oversell protection.
- Ditahan: payment proof upload karena flow manual saat ini tidak memakai bukti file.
- Ditahan: payment webhook, signature verification, dan provider callback karena payment gateway belum dipilih.
- Ditahan: production/provider credential tasks karena membutuhkan keputusan provider dan akses server.- [x] Kunci pemilihan transfer manual dengan verifikasi email customer untuk mencegah order IDOR.

- [x] Tambahkan upload bukti transfer manual dengan validasi email, file, storage, dan test.
- [x] Perbaiki QR e-ticket menjadi SVG string dan sembunyikan detail e-ticket sampai lookup status berhasil.
- [x] Tambahkan lampiran PDF e-ticket pada queued mail menggunakan template PDF dan QR code.
