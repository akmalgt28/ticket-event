# PRD - Platform Pemesanan Seminar & Workshop

**Status:** Draft v0.1  
**Scope:** Platform pribadi untuk satu organizer  
**Target awal:** Satu event  
**Tech stack utama:** Laravel + PostgreSQL + Inertia.js + Vue + Tailwind CSS + Vite

## 1. Executive Summary

### Problem Statement

Organizer kesulitan menjual tiket seminar atau workshop karena proses publikasi event, pencatatan peserta, pembayaran, dan validasi tiket masih tersebar di berbagai platform atau dilakukan manual.

Peserta juga membutuhkan proses pemesanan yang jelas, mulai dari menemukan event sampai menerima tiket digital.

### Proposed Solution

Membangun platform pemesanan event pribadi untuk satu organizer. Platform menyediakan halaman publik event, pemesanan tiket, pembayaran melalui transfer manual atau payment gateway, e-ticket QR code, serta dashboard organizer untuk mengelola event dan peserta.

### Success Criteria

MVP dianggap berhasil jika:

- Organizer dapat membuat dan mempublikasikan satu event tanpa bantuan developer.
- Peserta dapat menyelesaikan pemesanan tiket melalui desktop maupun mobile.
- Sistem mencatat status pesanan dan pembayaran secara konsisten.
- Peserta menerima e-ticket melalui email setelah pembayaran berhasil diverifikasi.
- Staff dapat memvalidasi tiket menggunakan QR code dan mencegah tiket dipakai lebih dari satu kali.
- Minimal 90% data peserta dan status pembayaran tercatat tanpa input ulang manual.

## 2. User Experience & Functionality

### User Personas

#### Organizer

Pemilik atau pengelola event yang membuat event, mengatur tiket, memantau penjualan, dan mengelola peserta.

#### Staff Event

Petugas yang membantu proses check-in peserta pada hari event.

#### Peserta

Pengunjung yang mencari event, memesan tiket, melakukan pembayaran, dan menggunakan e-ticket.

#### Administrator Sistem

Pada MVP, administrator dapat dirangkap oleh organizer. Role terpisah tetap disiapkan untuk kebutuhan permission.

### User Stories

#### Event Management

- Sebagai organizer, saya ingin membuat event agar informasi seminar/workshop dapat dipublikasikan.
- Sebagai organizer, saya ingin mengatur harga dan kuota tiket agar penjualan dapat dikontrol.
- Sebagai organizer, saya ingin mengubah status event agar event dapat disimpan sebagai draft, dipublikasikan, atau ditutup.
- Sebagai organizer, saya ingin melihat jumlah tiket terjual dan tersisa agar dapat memantau performa event.

#### Ticket Ordering

- Sebagai peserta, saya ingin melihat detail event agar dapat memutuskan apakah ingin membeli tiket.
- Sebagai peserta, saya ingin memilih jenis dan jumlah tiket agar sesuai kebutuhan.
- Sebagai peserta, saya ingin mengisi data peserta agar organizer memiliki informasi kehadiran.
- Sebagai peserta, saya ingin menerima nomor pesanan agar dapat melacak transaksi.

#### Payment

- Sebagai peserta, saya ingin memilih transfer manual atau payment gateway agar dapat membayar menggunakan metode yang tersedia.
- Sebagai organizer, saya ingin memverifikasi pembayaran manual agar pesanan dapat dikonfirmasi.
- Sebagai sistem, saya ingin menerima callback payment gateway agar status pembayaran diperbarui otomatis.

#### E-ticket

- Sebagai peserta, saya ingin menerima e-ticket setelah pembayaran berhasil agar dapat digunakan saat check-in.
- Sebagai peserta, saya ingin menerima e-ticket melalui email tanpa harus membuat akun.
- Sebagai staff, saya ingin memindai QR code agar proses check-in lebih cepat.
- Sebagai sistem, saya ingin menolak QR code yang sudah digunakan agar satu tiket tidak dipakai berulang.

#### Reporting

- Sebagai organizer, saya ingin melihat daftar peserta agar dapat menyiapkan kebutuhan event.
- Sebagai organizer, saya ingin mengekspor data peserta agar dapat digunakan untuk kebutuhan operasional.
- Sebagai organizer, saya ingin melihat rekap penjualan agar dapat mengevaluasi event.

### Acceptance Criteria

#### A. Membuat Event

- Organizer dapat mengisi nama event, deskripsi, banner, tanggal, waktu, lokasi, kontak, dan status.
- Event dapat disimpan sebagai `draft`.
- Event berstatus `published` tampil di halaman publik.
- Event berstatus `closed` tidak menerima pesanan baru.
- Event yang belum memiliki minimal satu tipe tiket tidak dapat dipublikasikan.

#### B. Mengelola Tiket

- Organizer dapat membuat tipe tiket seperti `Regular`, `VIP`, atau `Early Bird`.
- Setiap tipe tiket memiliki nama, harga, kuota, dan periode penjualan.
- Sistem menolak pesanan jika kuota tidak mencukupi.
- Kuota tiket tidak boleh menjadi negatif.
- Harga tiket yang sudah masuk order disimpan sebagai snapshot pada order.

#### C. Membuat Pesanan

- Peserta dapat memesan tanpa membuat akun pada MVP.
- Peserta wajib mengisi nama, email, nomor telepon, dan data peserta yang diperlukan.
- Sistem membuat nomor order unik.
- Order memiliki batas waktu pembayaran.
- Pesanan berstatus `pending` tidak mengurangi kuota secara permanen setelah batas waktu berakhir.
- Sistem tidak membuat e-ticket sebelum pembayaran dikonfirmasi.
- Email peserta wajib memiliki format valid karena menjadi tujuan utama pengiriman e-ticket.

#### D. Pembayaran

- Admin dapat mengonfirmasi pembayaran transfer manual.
- Sistem menyimpan metode pembayaran dan referensi transaksi.
- Callback payment gateway harus diverifikasi sebelum status order diubah.
- Callback yang sama tidak boleh memproses order dua kali.
- Status pembayaran minimal meliputi `pending`, `paid`, `failed`, `expired`, dan `refunded`.

#### E. E-ticket

- Sistem membuat e-ticket unik untuk setiap peserta atau tiket.
- E-ticket memiliki QR code yang mengarah ke token validasi, bukan data sensitif langsung.
- Sistem mengirim e-ticket ke email peserta setelah pembayaran berhasil.
- Peserta dapat mengunduh atau melihat e-ticket dari email tanpa login.
- Organizer dapat mengirim ulang e-ticket dari dashboard.
- Kegagalan pengiriman email tercatat dan dapat diproses ulang.
- Staff dapat memvalidasi tiket melalui halaman check-in.
- Tiket berstatus `used` tidak dapat digunakan kembali.
- Sistem mencatat waktu, user, dan lokasi atau perangkat check-in jika tersedia.

#### F. Dashboard Organizer

- Dashboard menampilkan jumlah order, tiket terjual, pendapatan, dan peserta.
- Organizer dapat memfilter order berdasarkan status pembayaran.
- Organizer dapat melihat detail peserta.
- Organizer dapat mengekspor data peserta dalam format CSV.
- Organizer dapat melakukan pencarian berdasarkan nomor order, nama, atau email.

### Non-Goals MVP

Fitur berikut tidak masuk versi awal:

- Multi-organizer atau marketplace publik.
- Aplikasi mobile native.
- Kursi bernomor.
- Seat map interaktif.
- Sistem komisi otomatis.
- Refund otomatis yang kompleks.
- Membership atau subscription.
- Event online dan integrasi streaming.
- Promo code kompleks.
- Multi-currency.
- Multi-bahasa.
- Waitlist otomatis.
- Akuntansi dan invoice pajak penuh.
- Integrasi CRM atau email marketing lanjutan.

## 3. AI System Requirements

### Status

Tidak ada fitur AI yang diperlukan untuk MVP.

### Rencana Opsional

AI dapat dipertimbangkan setelah alur utama stabil untuk:

- Membantu membuat deskripsi event.
- Membuat ringkasan event.
- Menjawab pertanyaan umum peserta.
- Menganalisis performa penjualan.

Fitur tersebut bukan bagian dari acceptance criteria MVP.

## 4. Technical Specifications

### Architecture Overview

Gunakan modular monolith Laravel:

```text
Browser
  -> Inertia.js
  -> Vue.js
  -> Laravel Web Routes / Controllers
  -> Application Services
  -> Eloquent ORM
  -> PostgreSQL
```

Komponen utama:

- **Laravel:** backend, routing, validation, authentication, authorization.
- **Inertia.js:** penghubung Laravel dengan Vue tanpa membuat API publik penuh.
- **Vue.js:** UI interaktif.
- **Tailwind CSS:** styling.
- **Vite:** asset bundling.
- **PostgreSQL:** database utama.
- **Laravel Queue:** pengiriman email, pembuatan tiket, notifikasi, dan pekerjaan async.
- **Laravel Scheduler:** pembersihan order expired dan pekerjaan periodik.
- **Object storage atau local storage:** banner event dan dokumen tiket.
- **Nginx/Apache melalui aaPanel:** web server di VPS.

Laravel API Resources dapat dipakai bila nanti tersedia aplikasi mobile atau integrasi eksternal. Untuk MVP berbasis Inertia, gunakan controller dan resource page terlebih dahulu agar tidak membuat lapisan API yang belum dibutuhkan.

### Modul Sistem

1. **Authentication**
   - Login organizer dan staff.
   - Tidak ada login peserta pada MVP.
   - Reset password.
   - Verifikasi email untuk akun internal.

2. **User & Role Management**
   - `owner`
   - `admin`
   - `staff`
   - `customer` jika akun peserta diaktifkan.

3. **Event Management**
   - CRUD event.
   - Draft, publish, close.
   - Upload banner.
   - Informasi lokasi dan jadwal.

4. **Ticket Management**
   - Tipe tiket.
   - Harga dan kuota.
   - Periode penjualan.
   - Status aktif/nonaktif.

5. **Order Management**
   - Pembuatan order.
   - Kalkulasi total.
   - Expiration.
   - Status pembayaran.
   - Riwayat perubahan status.

6. **Payment Management**
   - Transfer manual.
   - Payment gateway.
   - Webhook/callback.
   - Verifikasi pembayaran.
   - Idempotency.

7. **E-ticket & Check-in**
   - Token tiket.
   - QR code.
   - Validasi tiket.
   - Riwayat check-in.

8. **Reporting**
   - Dashboard metrik.
   - Daftar peserta.
   - Export CSV.
   - Rekap pembayaran.

### Entitas Data Awal

#### `users`

- `id`
- `name`
- `email`
- `password`
- `role`
- `email_verified_at`
- timestamps

#### `events`

- `id`
- `title`
- `slug`
- `description`
- `banner_path`
- `start_at`
- `end_at`
- `location_name`
- `location_address`
- `status`
- `published_at`
- timestamps

#### `ticket_types`

- `id`
- `event_id`
- `name`
- `description`
- `price`
- `quota`
- `sold_count`
- `sale_start_at`
- `sale_end_at`
- `status`
- timestamps

#### `orders`

- `id`
- `order_number`
- `event_id`
- `customer_name`
- `customer_email`
- `customer_phone`
- `subtotal`
- `discount_amount`
- `total_amount`
- `payment_method`
- `payment_status`
- `expires_at`
- `paid_at`
- timestamps

#### `order_items`

- `id`
- `order_id`
- `ticket_type_id`
- `ticket_name_snapshot`
- `unit_price`
- `quantity`
- `subtotal`
- timestamps

#### `attendees`

- `id`
- `order_id`
- `name`
- `email`
- `phone`
- `metadata`
- timestamps

#### `tickets`

- `id`
- `order_id`
- `order_item_id`
- `attendee_id`
- `ticket_number`
- `qr_token_hash`
- `status`
- `checked_in_at`
- `checked_in_by`
- timestamps

#### `payments`

- `id`
- `order_id`
- `provider`
- `method`
- `provider_transaction_id`
- `amount`
- `status`
- `paid_at`
- `raw_response`
- timestamps

#### `audit_logs`

- `id`
- `user_id`
- `action`
- `auditable_type`
- `auditable_id`
- `old_values`
- `new_values`
- `ip_address`
- `user_agent`
- timestamps

### Authentication & Authorization

Rekomendasi:

- **Laravel Fortify** untuk login, password reset, email verification, dan fitur authentication backend organizer/staff.
- **Laravel Sanctum** jika membutuhkan token API atau integrasi frontend/API eksternal.
- Untuk Inertia dalam satu aplikasi, gunakan session-based authentication sebagai mekanisme utama.
- **Spatie Laravel Permission** untuk role dan permission.
- Middleware permission untuk membatasi akses organizer, admin, dan staff.
- Role tidak boleh ditetapkan berdasarkan input request biasa; role harus ditetapkan melalui proses terotorisasi.

### Email Delivery

- Email peserta menjadi tujuan utama pengiriman e-ticket.
- Peserta tidak perlu membuat akun atau login untuk membeli tiket.
- Gunakan provider email transactional seperti **Resend** sebagai kandidat awal.
- API key dan konfigurasi provider disimpan di environment variable.
- Pengiriman email dilakukan melalui queue agar checkout tidak menunggu proses pengiriman.
- Simpan status pengiriman minimal sebagai `pending`, `sent`, `failed`, dan `retrying`.
- Simpan `message_id` provider jika tersedia untuk kebutuhan pelacakan.
- Email e-ticket harus berisi nomor order, detail event, identitas peserta, dan QR code.
- Sediakan aksi kirim ulang e-ticket dari dashboard organizer.

### Security & Privacy

- Password disimpan menggunakan hashing Laravel.
- Data sensitif tertentu dienkripsi menggunakan encrypted casts atau encryption service Laravel.
- QR code hanya berisi token acak atau signed token.
- Simpan hash token QR untuk validasi; jangan menyimpan token mentah jika tidak diperlukan.
- Validasi semua input melalui Form Request.
- Gunakan CSRF protection pada alur session.
- Gunakan rate limiting untuk login, checkout, dan validasi QR.
- Validasi webhook payment gateway melalui signature.
- Gunakan database transaction dan row locking saat reservasi kuota.
- Terapkan idempotency untuk callback pembayaran.
- Batasi upload berdasarkan MIME type, ukuran, dan ekstensi.
- Jangan menyimpan data kartu pembayaran.
- Gunakan HTTPS penuh di VPS.
- Jalankan backup database berkala dan uji proses restore.
- Simpan audit log untuk perubahan event, tiket, order, pembayaran, dan check-in.
- Jalankan dependency update dan security audit secara berkala.
- Hindari menambahkan package keamanan tanpa kebutuhan jelas; evaluasi package secara terpisah sebelum digunakan.

### Business Rules Penting

1. Satu order dapat memiliki beberapa tipe tiket.
2. Satu tiket memiliki satu QR code.
3. Order `pending` memiliki batas waktu pembayaran.
4. Order expired melepaskan kuota yang masih direservasi.
5. Order `paid` tidak dapat dibatalkan tanpa proses refund yang sah.
6. Tiket hanya dibuat setelah pembayaran berhasil.
7. Check-in harus atomic agar dua request bersamaan tidak memakai tiket dua kali.
8. Harga dalam `order_items` tidak mengikuti perubahan harga tiket setelah order dibuat.
9. Event `closed` tidak menerima order baru.
10. Semua perubahan status penting tercatat dalam audit log.

### Infrastruktur VPS

Minimum awal:

- Ubuntu LTS.
- Nginx.
- PHP versi yang kompatibel dengan versi Laravel yang dipilih.
- PostgreSQL.
- Redis untuk queue dan cache jika dibutuhkan.
- Supervisor untuk worker queue.
- SSL melalui Let's Encrypt.
- Firewall dan pembatasan akses SSH.
- Backup database ke lokasi terpisah.
- Deployment melalui Git atau pipeline sederhana.

aaPanel dapat dipakai sebagai panel operasional, tetapi konfigurasi aplikasi tetap perlu dikontrol melalui environment variable, deployment script, backup, dan monitoring yang jelas.

## 5. Risks & Roadmap

### Phased Rollout

#### MVP

- Authentication organizer dan staff.
- CRUD event.
- Tipe tiket dan kuota.
- Halaman publik event.
- Checkout.
- Transfer manual.
- E-ticket QR code.
- Check-in.
- Dashboard penjualan.
- Export CSV.

#### v1.1

- Payment gateway.
- Email otomatis untuk order dan e-ticket.
- Promo code sederhana.
- Notifikasi WhatsApp atau SMS.
- Laporan penjualan yang lebih lengkap.
- Multiple event aktif.

#### v2.0

- Multi-organizer.
- Komisi platform.
- Custom branding per organizer.
- Kursi bernomor.
- Refund otomatis.
- Integrasi CRM.
- Aplikasi mobile staff.
- Event online.
- Analitik peserta.

### Technical Risks

#### 1. Overselling Kuota

**Risiko:** Dua peserta membeli tiket terakhir secara bersamaan.

**Mitigasi:** Gunakan database transaction, row-level locking, dan validasi kuota di server.

#### 2. Duplikasi Webhook

**Risiko:** Payment gateway mengirim callback lebih dari sekali.

**Mitigasi:** Simpan transaction ID, gunakan idempotency, dan proses callback secara atomic.

#### 3. Pembayaran Manual Tidak Terverifikasi

**Risiko:** Pesanan dikonfirmasi tanpa bukti pembayaran valid.

**Mitigasi:** Admin-only verification, upload bukti pembayaran opsional, audit log, dan pemisahan status order/payment.

#### 4. QR Code Dipakai Berulang

**Risiko:** Tiket digunakan oleh lebih dari satu orang.

**Mitigasi:** Lock row saat check-in dan ubah status tiket secara atomic.

#### 5. Kehilangan Data VPS

**Risiko:** Database rusak atau VPS tidak tersedia.

**Mitigasi:** Backup otomatis, backup off-server, monitoring, dan prosedur restore yang diuji.

#### 6. Scope Membesar

**Risiko:** Proyek berubah menjadi marketplace event sebelum MVP selesai.

**Mitigasi:** Tetapkan bahwa MVP hanya mendukung satu organizer internal dan satu event awal.

### Keputusan yang Masih `TBD`

- Payment gateway yang digunakan.
- Provider email transactional final; Resend menjadi kandidat awal.
- Format data peserta tambahan.
- Kebijakan refund.
- Besaran batas waktu pembayaran.
- Apakah organizer membutuhkan custom domain atau branding.
- Detail laporan keuangan.
- Provider storage untuk banner dan dokumen tiket.

