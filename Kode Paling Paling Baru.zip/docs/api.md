# API aktif

Base URL lokal: `/api`

Semua response sukses memakai format resource Laravel dengan payload utama pada `data`. Endpoint yang mengubah state memakai validasi request dan rate limit sesuai route.

## Public

### `GET /api/events`

Daftar event berstatus `published` dan ticket type yang sedang aktif dalam periode penjualan.

Query:
- `search` opsional: cari judul, lokasi, atau deskripsi.

### `GET /api/events/{slug}`

Detail event publik berdasarkan slug. Event draft/closed tidak tersedia.

### `POST /api/orders`

Membuat order guest dan melakukan reservasi kuota dalam transaksi.

Payload wajib:
```json
{
  "event_id": 1,
  "customer_name": "Nama Customer",
  "customer_email": "customer@example.com",
  "customer_phone": "08123456789",
  "items": [{ "ticket_type_id": 1, "quantity": 2 }],
  "attendees": [{ "name": "Peserta", "email": "peserta@example.com", "phone": "08123456789" }]
}
```

Server menghitung ulang total. `total_amount`, `subtotal`, dan `discount_amount` dari client ditolak.

### `POST /api/orders/{order}/payments/manual`

Memilih transfer bank manual untuk order pending.

Payload:
```json
{ "method": "bank_transfer", "customer_email": "customer@example.com" }
```

Endpoint idempotent untuk payment pending yang sama. Bukti transfer belum digunakan pada flow saat ini; verifikasi dilakukan organizer berdasarkan reference dan catatan.

### `POST /api/orders/status`

Mencari status order secara publik.

Payload:
```json
{ "order_number": "ORD-...", "customer_email": "customer@example.com" }
```

## Internal

### `POST /payments/verify`

Membayar atau menolak payment manual. Wajib session user terverifikasi dengan permission `payments.verify`.

Payload:
```json
{
  "order_id": 1,
  "status": "paid",
  "provider_transaction_id": "TRX-123",
  "note": "Transfer sesuai mutasi"
}
```

`provider_transaction_id` unik dan tidak boleh dipakai dua payment. Verifikasi paid menerbitkan ticket, membuat audit log, dan queue e-ticket.

### `POST /check-in`

Memvalidasi QR token atau ticket number. Wajib role/permission check-in dan rate limit.

Payload salah satu:
```json
{ "token": "qr-token" }
```

atau:
```json
{ "ticket_number": "TKT-..." }
```

## Belum aktif

- Payment gateway webhook belum dibuat karena provider belum dipilih.
- Signature webhook dan callback idempotency provider menunggu keputusan provider.
- Upload bukti transfer belum dibuat karena flow manual saat ini belum memakai file bukti.